#!/bin/bash

# Define the file path relative to the script's location
file="./License.dat"

# Replace <put.hostname.here> with localhost
sed -i 's/<put.hostname.here>/localhost/g' "$file"

# Replace PATH with /home/$USER/Microchip/Libero_SoC_2025.1/LicenseDaemons
sed -i 's|PATH|/home/$USER/Microchip/Libero_SoC_2025.1/LicenseDaemons|g' "$file"

echo "License.dat has been updated successfully!"
